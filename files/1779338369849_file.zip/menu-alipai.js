/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 *
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 */

require('./settings');
require('./alipai-cmd');
const fs = require('fs');
const chalk = require('chalk');

global.menusticker = `
╭─❏ 𝗦𝘁𝗶𝗰𝗸𝗲𝗿𝘀 - 𝗠𝗲𝗻𝘂
│▣ .brat
│▣ .bratvid
│▣ .bratanime
│▣ .bratgambar
│▣ .bratgambarhd
│▣ .bratimg3
│▣ .bratpink
│▣ .ytcomment
│▣ .emoji
│▣ .emojigif
│▣ .emojimix
│▣ .manusialidi
│▣ .qc
│▣ .smeme
│▣ .sticker
│▣ .stikeranime
│▣ .stikerdinokuning
│▣ .stikergojo
│▣ .stikermukalu
│▣ .stikerpentol
│▣ .stikerrandom
│▣ .stikerspongebob
│▣ .swm 
│▣ .toimg
│▣ .tvstiker
╰──────────❏`

global.menutools = `
╭─❏ 𝗧𝗼𝗼𝗹𝘀 - 𝗠𝗲𝗻𝘂
│▣ .web2apk
│▣ .removeobject
│▣ .volume
│▣ .volumevideo
│▣ .img2pdf
│▣ .ceknamadana
│▣ .createhtml
│▣ .saveweb
│▣ .ttsbrando
│▣ .ptvch
│▣ .font1 - .font10
│▣ .voicecover 
│▣ .vocalremover
│▣ .tempo
│▣ .speech2text 
│▣ .sidompul
│▣ .togif
│▣ .tovn
│▣ .hdvid 
│▣ .tomp3
│▣ .ai
│▣ .aitts
│▣ .ambilsw
│▣ .donate
│▣ .enc 
│▣ .enchard 
│▣ .fakecall
│▣ .getpp
│▣ .gptonline
│▣ .gptimg
│▣ .hd
│▣ .iqc
│▣ .kapanreset
│▣ .ngl
│▣ .nulis
│▣ .ocr 
│▣ .rch
│▣ .rvo 
│▣ .shortlink
│▣ .shortlink2
│▣ .ssweb
│▣ .struk
│▣ .texttosound
│▣ .tourl
│▣ .tourl2 
│▣ .tourl3
│▣ .top4top
│▣ .catbox 
│▣ .qu 
│▣ .uguu 
│▣ .pixhost 
│▣ .translate
│▣ .ytsummarizer
│▣ .cfsub
│▣ .listsubdo
│▣ .delsubdo
│▣ .infosubdo
│▣ .syncsubdo
╰──────────❏`

global.menumaker = `
╭─❏ 𝗠𝗮𝗸𝗲𝗿 - 𝗠𝗲𝗻𝘂
│▣ .todemo
│▣ .fakechannel
│▣ .fakewhatsapp
│▣ .wanted
│▣ .musikcard
│▣ .fakeff
│▣ .fakegroup
│▣ .topenjara 
│▣ .sharkstudio 
│▣ .alipedit 
│▣ .putihkan 
│▣ .aiedit 
│▣ .banana 
│▣ .hijabpin 
│▣ .hitamin
│▣ .tobotak 
│▣ .tomountain
│▣ .tochibi 
│▣ .todino 
│▣ .polaroid 
│▣ .tofootball 
│▣ .animediff 
│▣ .photoai
│▣ .fakektp
│▣ .carbon
│▣ .tofigure 
│▣ .telanjang 
│▣ .fakestory
│▣ .tosunda 
│▣ .tojawa 
│▣ .todonghua 
│▣ .tomanhwa 
│▣ .toanime 
│▣ .tomanga 
│▣ .sdm 
│▣ .tomoai
│▣ .topacar
│▣ .tomonyet
│▣ .tosatan
│▣ .toroblox
│▣ .topunk
│▣ .tomangu
│▣ .tosad
│▣ .todpr
│▣ .tobabi
│▣ .buatgambar
│▣ .buatlagu 
│▣ .buatvideo 
│▣ .ghibli 
│▣ .jadidisney
│▣ .jadigta
│▣ .jadipixar
│▣ .nglspam 
│▣ .tokartun 
│▣ .veo3 
│▣ .zrooart
│▣ .tospiderman
│▣ .tonaruto
│▣ .tobatman
│▣ .tosuperman
│▣ .toironman
│▣ .tocaptainamerica
│▣ .tothor
│▣ .tohulk
│▣ .towolverine
│▣ .todeadpool
│▣ .toflash
│▣ .toaquaman
│▣ .tocyan
│▣ .tovision
│▣ .toblackpanther
│▣ .tostarlord
│▣ .togroot
│▣ .torocket
│▣ .todracula
│▣ .tofrankenstein
│▣ .tozombie
│▣ .tovampire
│▣ .toghost
│▣ .toskeleton
│▣ .todevil
│▣ .toangel
│▣ .tofairy
│▣ .towizard
│▣ .towinged
│▣ .toelf
│▣ .todwarf
│▣ .toorc
│▣ .totroll
│▣ .togiant
│▣ .tominotaur
│▣ .tomedusa
│▣ .tocentaur
│▣ .togriffin
│▣ .tophoenix
│▣ .todragon
│▣ .tounicorn
│▣ .topeacock
│▣ .towolf
│▣ .tofox
│▣ .tobear
│▣ .tolion
│▣ .totiger
│▣ .topanda
│▣ .tokoala
│▣ .topenguin
│▣ .toowl
│▣ .toeagle
│▣ .tofalcon
│▣ .toraven
│▣ .tocrow
│▣ .tosnake
│▣ .toshark
│▣ .tocrocodile
│▣ .tooctopus
│▣ .tojellyfish
│▣ .tostarfish
│▣ .toseahorse
│▣ .todolphin
│▣ .towhale
│▣ .torobot
│▣ .tocyborg
│▣ .toandroid
│▣ .toalien
│▣ .toufo
│▣ .toastronaut
│▣ .tocosmonaut
│▣ .toscuba
│▣ .todiver
│▣ .topirate
│▣ .tocowboy
│▣ .toninja
│▣ .tosamurai
│▣ .toviking
│▣ .toknight
│▣ .toarcher
│▣ .tomage
│▣ .tocleric
│▣ .tobard
│▣ .torogue
│▣ .tomonk
│▣ .tobarbarian
│▣ .tonecromancer
│▣ .todruid
│▣ .toranger
│▣ .topaladin
│▣ .togunslinger
│▣ .tomechanic
│▣ .toscientist
│▣ .todoctor
│▣ .toengineer
│▣ .toartist
│▣ .tosinger
│▣ .todancer
│▣ .toactor
│▣ .todirector
│▣ .towriter
│▣ .tophotographer
│▣ .tochef
│▣ .tobaker
│▣ .tobarista
│▣ .tobartender
│▣ .topilot
│▣ .todriver
│▣ .tosailor
│▣ .tosoldier
│▣ .topoliceman
│▣ .tofirefighter
│▣ .toteacher
│▣ .toprofessor
│▣ .tostudent
│▣ .toprogrammer
│▣ .todesigner
│▣ .totester
│▣ .tomanager
│▣ .toboss
│▣ .toceo
│▣ .tocfo
│▣ .tocoo
│▣ .tocmo
│▣ .tocto
│▣ .tocpo
│▣ .tocko
│▣ .toclown
│▣ .tomime
│▣ .tojester
│▣ .tomagician
│▣ .toillusionist
│▣ .toescapeartist
│▣ .toacrobat
│▣ .tocontortionist
│▣ .toswordswallower
│▣ .tofirebreather
│▣ .tojugger
│▣ .tounicyclist
│▣ .totightrope
│▣ .totrapeze
│▣ .toaerialist
│▣ .tocannon
│▣ .tostilts
│▣ .tomask
│▣ .tomummy
│▣ .tozorro
│▣ .tosherlock
│▣ .tophantom
│▣ .todraco
│▣ .tohannibal
│▣ .tojoker
│▣ .tovenom
│▣ .tocarnage
│▣ .togreen
│▣ .tolizard
│▣ .torhino
│▣ .tovulture
│▣ .toelectro
│▣ .tosandman
│▣ .tomysterio
│▣ .togoblin
│▣ .tochemo
│▣ .toloki
│▣ .tothanos
│▣ .togalactus
│▣ .todarkseid
│▣ .tobrainiac
│▣ .todoomsday
│▣ .tobizarro
│▣ .tometallo
│▣ .toparasite
│▣ .togrodd
│▣ .tocircus
│▣ .toreverse
│▣ .tomirror
│▣ .togold
│▣ .tosilver
│▣ .tobronze
│▣ .tocopper
│▣ .tosteel
│▣ .tocarbon
│▣ .tocrystal
│▣ .todiamond
│▣ .tosapphire
│▣ .toruby
│▣ .toemerald
│▣ .totopaz
│▣ .toamethyst
│▣ .toopal
│▣ .toperidot
│▣ .toaquamarine
│▣ .tocitrine
│▣ .totourmaline
│▣ .togarnet
│▣ .tospinel
│▣ .tozircon
│▣ .totanzanite
│▣ .toiolite
│▣ .tohematite
│▣ .tomoonstone
│▣ .tosunstone
│▣ .tostarstone
│▣ .tocomet
│▣ .tometeor
│▣ .toasteroid
│▣ .tonebula
│▣ .togalaxy
│▣ .touniverse
│▣ .toblackhole
│▣ .towormhole
│▣ .toportal
│▣ .totime
│▣ .tospace
│▣ .todimension
│▣ .toparallel
│▣ .toalternate
│▣ .tomultiverse
│▣ .tomegaverse
│▣ .tometaverse
│▣ .toomniverse
╰──────────❏`

global.menuprimbon = `
╭─❏ 𝗣𝗿𝗶𝗺𝗯𝗼𝗻 - 𝗠𝗲𝗻𝘂
│▣ .artinama
│▣ .cekaura
│▣ .ceksial
│▣ .darkjoke
│▣ .isidompet
│▣ .jodohmakanan
│▣ .kecocokannama
│▣ .nasibbatere
│▣ .nomerhoki
│▣ .pantun
│▣ .profesiku
│▣ .quotes
│▣ .ramalancinta
│▣ .ramalanjodoh
│▣ .ramalanjodohbali
│▣ .ramalannasib
│▣ .scankontol
│▣ .scanmemek
│▣ .suamiistri
│▣ .zodiak
╰──────────❏`

global.menufun = `
╭─❏ 𝗙𝘂𝗻 - 𝗠𝗲𝗻𝘂
│▣ .fitnah
│▣ .sad1 - sad55
│▣ .sound1 - sound200
│▣ .artinama
│▣ .cekbeban
│▣ .cekbucin
│▣ .cekfemboy
│▣ .cekgay
│▣ .cekjodoh
│▣ .cekjones
│▣ .cekkaya
│▣ .cekkodam
│▣ .cekkontol
│▣ .cekmasadepan
│▣ .cekmemek
│▣ .ceksange
│▣ .cekstress
│▣ .cekwibu
│▣ .fakeml
│▣ .faktadunia
│▣ .faktaunik
│▣ .infonegara
│▣ .jumlahuser
│▣ .kecocokanpasangan
│▣ .kirimch
│▣ .meme
│▣ .pakustad
│▣ .planet
│▣ .quotesanime
│▣ .sertifikattolol
│▣ .tafsirmimpi
│▣ .waifu
╰──────────❏`

global.menudownload = `
╭─❏ 𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱 - 𝗠𝗲𝗻𝘂
│▣ .tiktok
│▣ .tiktokmp3
│▣ .twitter
│▣ .ytmp3
│▣ .ytmp4
│▣ .pinterest
│▣ .pindl
│▣ .alipdl support all link
│▣ .capcut
│▣ .facebook
│▣ .gitclone
│▣ .gdrive
│▣ .instagram
│▣ .mediafire
│▣ .pastebin
│▣ .play1
│▣ .spdown
│▣ .telesticker
│▣ .threads
╰──────────❏`

global.menuai = `
╭─❏ 𝗔𝗜 - 𝗠𝗲𝗻𝘂
│▣ .duckai
│▣ .luma
│▣ .img2video
│▣ .copilotvoice
│▣ .aimention
│▣ .publicai
│▣ .powerbrain
│▣ .venice
│▣ .webpilot
│▣ .logicbell
│▣ .bard
│▣ .hyperai
│▣ .autoai
│▣ .ai
│▣ .airealtime
│▣ .gpt5plus 
│▣ .soraai 
│▣ .openai 
│▣ .groq
│▣ .customai 
╰──────────❏`

global.menusearch = `
╭─❏ 𝗦𝗲𝗮𝗿𝗰𝗵 - 𝗠𝗲𝗻𝘂
│▣ .toproblox
│▣ .gsmarena
│▣ .wattpad
│▣ .searchgame
│▣ .soundcloud
│▣ .npmjs
│▣ .whatmusik
│▣ .lirik
│▣ .ptv
│▣ .myanimelist
│▣ .searchanime
│▣ .animeinfo
│▣ .searchchar
│▣ .charinfo
│▣ .carigrupwa
│▣ .caristiker
│▣ .cekgempa
│▣ .cekkalender
│▣ .cekml
│▣ .cekff
│▣ .cekcuaca
│▣ .cnbc
│▣ .cnn
│▣ .hiitwixtor
│▣ .igstalk
│▣ .otakudesu
│▣ .pinterest/pin
│▣ .play
│▣ .playch
│▣ .playtiktok
│▣ .playv2
│▣ .playvid
│▣ .spotify
│▣ .stalkroblox
│▣ .tiktokstalk
│▣ .yts
╰──────────❏`

global.menugame = `
╭─❏ 𝗚𝗮𝗺𝗲 - 𝗠𝗲𝗻𝘂
│▣ .werewolf
│▣ .tictactoe
│▣ .kuismath
│▣ .sambungkata
│▣ .sambungkata2
│▣ .tebakhero
│▣ .tebakgenshin
│▣ .asahotak
│▣ .bom
│▣ .caklontong
│▣ .family100
│▣ .kuis
│▣ .lengkapikalimat
│▣ .siapakahaku
│▣ .susunkata
│▣ .tebakanime
│▣ .tebakbendera
│▣ .tebakff
│▣ .tebakgame
│▣ .tebakgambar
│▣ .tebakhewan
│▣ .tebakinggris
│▣ .tebakjkt
│▣ .tebakjorok
│▣ .tebakkah
│▣ .tebakkalimat
│▣ .tebakkata
│▣ .tebaklagu
│▣ .tebaklirik
│▣ .tebaklogo
│▣ .tebakmakanan
│▣ .tekateki
╰──────────❏`

global.menuenc = `
╭─❏ 𝗘𝗻𝗰𝗿𝘆𝗽𝘁 - 𝗠𝗲𝗻𝘂
│▣ .enccustom <nama>
│▣ .encinvis
│▣ .encsiu
│▣ .encstrong
│▣ .encultra
│▣ .enchard 
│▣ .enc 
│▣ .encryptcustom <nama>
│▣ .encryptinvis
│▣ .encryptsiu
│▣ .encryptstrong
│▣ .encryptultra
│▣ .customenc <nama>
│▣ .invisenc
│▣ .siuenc
│▣ .strongenc
│▣ .ultraenc
│▣ .custom-encrypt <nama>
│▣ .invis-encrypt
│▣ .siu-encrypt
│▣ .strong-encrypt
│▣ .ultra-encrypt
│▣ .enc-custom <nama>
│▣ .enc-invis
│▣ .enc-siu
│▣ .enc-strong
│▣ .enc-ultra
│▣ .enccustomjs <nama>
│▣ .encinvisible
│▣ .encryptinvisible
│▣ .invisibleenc
│▣ .invisible-encrypt
│▣ .enc-invisible
│▣ .eninvisiblejs
│▣ .jsinvisenc
│▣ .encjsinvis
│▣ .encsiujs
│▣ .jssiuenc
│▣ .siujsen
│▣ .encstrongjs
│▣ .jsstrongenc
│▣ .strongjsen
│▣ .encultrajs
│▣ .jsultraenc
│▣ .ultrajsen
│▣ .encryptcustomjs <nama>
│▣ .customjsen <nama>
╰──────────❏`

global.menustk = `
╭─❏ 𝗦𝘁𝗶𝗰𝗸𝗲𝗿 - 𝗠𝗲𝗻𝘂
│▣ .stkbaik
│▣ .stkcantik
│▣ .stkganteng
│▣ .stkhitam
│▣ .stkmiskin
│▣ .stkkaya
│▣ .stkmarah
│▣ .stksabar
│▣ .stksakiti
│▣ .stkkeren
│▣ .stkmisterius
│▣ .stksantai
│▣ .stksombong
│▣ .stklucu
│▣ .stkgila
╰──────────❏`

global.menurpg = `
╭─❏ 𝗥𝗣𝗚 𝗚𝗮𝗺𝗲 - 𝗠𝗲𝗻𝘂
│▣ .daftar
│▣ .profile
│▣ .unreg
│▣ .werewolf
│▣ .buatstreak
│▣ .nyalainstreak 
│▣ .streak
│▣ .topstreak
│▣ .adopsipet
│▣ .attack
│▣ .begal
│▣ .berkebun
│▣ .buy
│▣ .claim
│▣ .craft
│▣ .daily
│▣ .dungeon
│▣ .equip
│▣ .flee
│▣ .spacegame
│▣ .foraging
│▣ .infopet
│▣ .inventory
│▣ .item
│▣ .jobkerja
│▣ .judionline
│▣ .kerja
│▣ .leaderboardrpg
│▣ .limit
│▣ .maling
│▣ .mancing
│▣ .mancingstart
│▣ .me
│▣ .meramu
│▣ .mining
│▣ .ngaji
│▣ .ngelonte
│▣ .ngocok
│▣ .ngojek
│▣ .openbo
│▣ .pvp
│▣ .quest
│▣ .rpgexplore
│▣ .rpghelp
│▣ .rpginv
│▣ .rpgmove
│▣ .rpgshop
│▣ .rpgstart
│▣ .rpgstats
│▣ .sell
│▣ .skill
│▣ .tambang
│▣ .toplevel
│▣ .use
│▣ .unequip
│▣ .tfgold
│▣ .cekgold
│▣ .topgold
│▣ .addgold
│▣ .lb_rpg
│▣ .besi
│▣ .nikel
│▣ .emas
│▣ .berlian
╰──────────❏`

global.menuephoto = `
╭─❏ 𝗘𝗽𝗵𝗼𝘁𝗼 - 𝗠𝗲𝗻𝘂
│▣ .glitchtext
│▣ .writetext
│▣ .advancedglow
│▣ .typographytext
│▣ .pixelglitch
│▣ .neonglitch
│▣ .flagtext
│▣ .flag3dtext
│▣ .deletingtext
│▣ .blackpinkstyle
│▣ .glowingtext
│▣ .underwatertext
│▣ .logomaker
│▣ .cartoonstyle
│▣ .papercutstyle
│▣ .watercolortext
│▣ .effectclouds
│▣ .blackpinklogo
│▣ .gradienttext
│▣ .summerbeach
│▣ .luxurygold
│▣ .multicoloredneon
│▣ .sandsummer
│▣ .galaxywallpaper
│▣ .1917style
│▣ .makingneon
│▣ .royaltext
│▣ .freecreate
│▣ .galaxystyle
│▣ .lighteffects
│▣ .blackpink
│▣ .dragonfire
│▣ .eraser
│▣ .galaxy
│▣ .grafitti
│▣ .horor
│▣ .incandescent
│▣ .nightstars
│▣ .pig
│▣ .pubg
│▣ .sunlight
│▣ .wood
│▣ .ytgoldbutton
│▣ .ytsilverbutton
╰──────────❏`

global.menuislam = `
╭─❏ 𝗜𝘀𝗹𝗮𝗺𝗶 - 𝗠𝗲𝗻𝘂
│▣ .asmaulhusna
│▣ .audiosurah
│▣ .ayatkursi
│▣ .bacaansholat
│▣ .doa
│▣ .doaharian
│▣ .hadits
│▣ .jadwalsholat
│▣ .kisahnabi
│▣ .niatsholat
│▣ .quotesislami
│▣ .wirid
╰──────────❏`

global.menucecan = `
╭─❏ 𝗖𝗲𝗰𝗮𝗻 - 𝗠𝗲𝗻𝘂
│▣ .cecanchina
│▣ .cecanhijaber
│▣ .cecanindonesia
│▣ .cecanjapan
│▣ .cecanjeni
│▣ .cecanjiso
│▣ .cecankorea
│▣ .cecanmalaysia
│▣ .cecanjustinaxie
│▣ .cecanrose
│▣ .cecanryujin
│▣ .cecanthailand
│▣ .cecanvietnam
╰──────────❏`

global.menupanel = `
╭─❏ 𝗣𝗮𝗻𝗲𝗹 - 𝗠𝗲𝗻𝘂
│▣ .1gb
│▣ .2gb
│▣ .3gb
│▣ .4gb
│▣ .5gb
│▣ .6gb
│▣ .7gb
│▣ .unli
│▣ .mypanel
│▣ .listpanel
│▣ .listuser
│▣ .renewserver
│▣ .notif
│▣ .delsrv
│▣ .deluser
│▣ .setpanel
│▣ .installpanel
│▣ .addreseller
│▣ .cekres
│▣ .delreseller
│▣ .listreseller
│▣ .cadp
╰──────────❏`

global.menunsfw = `
╭─❏ 𝗡𝗦𝗙𝗪 - 𝗠𝗲𝗻𝘂
│▣ .nsfw 
│▣ .nsfwahegao 
│▣ .nsfwass 
│▣ .nsfwbdsm 
│▣ .nsfwgangbang 
│▣ .nsfwgay 
│▣ .nsfwloli 
│▣ .nsfwneko 
│▣ .nsfwpussy 
│▣ .nsfwzettai 
╰──────────❏`

global.menuanime = `
╭─❏ 𝗔𝗻𝗶𝗺𝗲 - 𝗠𝗲𝗻𝘂
│▣ .animeakira
│▣ .animeasuna
│▣ .animeeba
│▣ .animeelaina
│▣ .animeemilia
│▣ .animegremory
│▣ .animehinata
│▣ .animehusbu
│▣ .animeisuzu
│▣ .animeitori
│▣ .animekagura
│▣ .animekanna
│▣ .animemegumin
│▣ .animemiku
│▣ .animenezuko
│▣ .animensfwloli
│▣ .animepokemon
│▣ .animerem
│▣ .animeryuko
│▣ .animeshina
│▣ .animeshinka
│▣ .animeshota
│▣ .animetejina
│▣ .animetoukachan
│▣ .animewaifu
│▣ .animeyotsuba
│▣ .animeyuli
│▣ .animeyumeko
│▣ .animezero
╰──────────❏`

global.potoanime = `
╭─❏ 𝗔𝗻𝗶𝗺𝗲 / 𝗧𝗵𝗲𝗺𝗮 - 𝗠𝗲𝗻𝘂
│▣ .akiyama
│▣ .ana
│▣ .art
│▣ .asuna
│▣ .ayuzawa
│▣ .boruto
│▣ .bts
│▣ .cartoon
│▣ .chiho
│▣ .chitoge
│▣ .cosplay
│▣ .cosplayloli
│▣ .cosplaysagiri
│▣ .cyber
│▣ .deidara
│▣ .doraemon
│▣ .forcexyz
│▣ .emilia
│▣ .erza
│▣ .exo
│▣ .gamewallpaper
│▣ .gremory
│▣ .hacker
│▣ .hestia
│▣ .hinata
│▣ .husbu
│▣ .inori
│▣ .islamic
│▣ .isuzu
│▣ .itachi
│▣ .itori
│▣ .jennie
│▣ .jiso
│▣ .justina
│▣ .kaga
│▣ .kagura
│▣ .kakasih
│▣ .kaori
│▣ .keneki
│▣ .kotori
│▣ .kurumi
│▣ .lisa
│▣ .madara
│▣ .megumin
│▣ .mikasa
│▣ .mikey
│▣ .miku
│▣ .minato
│▣ .mountain
│▣ .naruto
│▣ .neko2
│▣ .nekonime
│▣ .nezuko
│▣ .onepiece
│▣ .pentol
│▣ .pokemon
│▣ .programming
│▣ .randomnime
│▣ .randomnime2
│▣ .rize
│▣ .rose
│▣ .sagiri
│▣ .sakura
│▣ .sasuke
│▣ .satanic
│▣ .shina
│▣ .shinka
│▣ .shinomiya
│▣ .shizuka
│▣ .shota
│▣ .shortquote
│▣ .space
│▣ .technology
│▣ .tejina
│▣ .toukachan
│▣ .tsunade
│▣ .yotsuba
│▣ .yuki
│▣ .yulibocil
│▣ .yumeko
╰──────────❏`

global.menustore = `
╭─❏ 𝗦𝘁𝗼𝗿𝗲 - 𝗠𝗲𝗻𝘂
│▣ .list
│▣ .setlist
│▣ .addlist
│▣ .dellist
│▣ .clearlist
│▣ .setpay
│▣ .delpay
│▣ .listpay
│▣ .setdone
│▣ .setproses
│▣ .done
│▣ .proses
│▣ .testimoni
│▣ .buyprem
│▣ .buysewagc
│▣ .done
│▣ .jpm
│▣ .jpm2
│▣ .jpmtesti
│▣ .payment
│▣ .proses
│▣ .pushkontak
│▣ .pushkontak2
│▣ .sendtesti
╰──────────❏`

global.menugroup = `
╭─❏ 𝗚𝗿𝗼𝘂𝗽 - 𝗠𝗲𝗻𝘂
│▣ .autolevel
│▣ .setclosetime
│▣ .setopentime
│▣ .cekjadwal
│▣ .resetjadwal
│▣ .autosholat
│▣ .addbadword
│▣ .listbadword
│▣ .delbadword
│▣ .banfitur
│▣ .intro
│▣ .setintro
│▣ .closetime
│▣ .opentime
│▣ .warn
│▣ .listwarn
│▣ .delwarn
│▣ .infowarn
│▣ .resetwarn
│▣ .infogrup
│▣ .hidetagpoll
│▣ .gcsider
│▣ .sidercek
│▣ .siderkick
│▣ .infouser
│▣ .setnamagc
│▣ .setppgc
│▣ .schedule
│▣ .autoabsen
│▣ .setabsen
│▣ .tagadmin
│▣ .acc
│▣ .tolakacc
│▣ .swgc
│▣ .swgcall
│▣ .totalchat
│▣ .resettotalchat
│▣ .setultah
│▣ .ultah
│▣ .delultah
│▣ .listultah
│▣ .afk
│▣ .onlyadmin
│▣ .add
│▣ .cekidch
│▣ .cekidgc
│▣ .close
│▣ .setclose
│▣ .setopen
│▣ .demote
│▣ .hidetag
│▣ .kick
│▣ .kudeta
│▣ .leaderboard
│▣ .leave
│▣ .linkgc
│▣ .off
│▣ .on
│▣ .open
│▣ .promote
│▣ .resetlinkgc
│▣ .setleft
│▣ .setwelcome
│▣ .testwelcome
│▣ .testleft
│▣ .tagall
╰──────────❏`

global.menuowner = `
╭─❏ 𝗢𝘄𝗻𝗲𝗿 - 𝗠𝗲𝗻𝘂
│▣ .addrespon
│▣ .delrespon
│▣ .listrespon
│▣ .autocorrect
│▣ .setrestart
│▣ .setlabel
│▣ .addpremgc
│▣ .delpremgc
│▣ .mutegc
│▣ .unmutegc
│▣ .sistemsewa
│▣ .autoreactsw
│▣ .autosambut 
│▣ .addprefix
│▣ .listprefix
│▣ .sefprefix
│▣ .renamebot
│▣ .setaudiomenu 
│▣ .setimage
│▣ .culikmember
│▣ .setdaftar
│▣ .setmenu
│▣ .stikercmd
│▣ .delstikercmd
│▣ .addaksesprem
│▣ .delaksesprem
│▣ .listaksesprem
│▣ .onlyprem
│▣ .addcase
│▣ .addlimit
│▣ .addlimitall
│▣ .addowner
│▣ .addprem
│▣ .addsewagc
│▣ .listsewagc
│▣ .delsewagc
│▣ .ceksewagc
│▣ .renewsewagc 
│▣ .antibot
│▣ .autobackup
│▣ .autoread
│▣ .autoreadsw
│▣ .autotyping
│▣ .backup
│▣ .blacklist
│▣ .cekprem
│▣ .clearchat
│▣ .clearprem
│▣ .creategc
│▣ .delcase
│▣ .dellimit
│▣ .delowner
│▣ .delprem
│▣ .getcase
│▣ .getsc
│▣ .joinch
│▣ .joingc
│▣ .listcase
│▣ .listgc
│▣ .listowner
│▣ .listprem
│▣ .pay2
│▣ .resetdb
│▣ .resetlimitall
│▣ .restartbot
│▣ .savekontak
│▣ .self/public
│▣ .setlimit
│▣ .setppbot
│▣ .unblacklist
│▣ .upchannel
│▣ .upchannel2
╰──────────❏`

global.allmenu = `${global.menusticker}
${global.menutools}
${global.menumaker}
${global.menuprimbon}
${global.menufun}
${global.menudownload}
${global.menuai}
${global.menusearch}
${global.menugame}
${global.menuenc}
${global.menustk}
${global.menurpg}
${global.menuephoto}
${global.menuislam}
${global.menucecan}
${global.menupanel}
${global.menunsfw}
${global.menuanime}
${global.potoanime}
${global.menustore}
${global.menugroup}
${global.menuowner}`

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});