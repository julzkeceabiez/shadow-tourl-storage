/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 *
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 */

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")
global.baileys = require('./package.json').dependencies['@whiskeysockets/baileys'] || 'unknown';
global.internalValidationKey = Buffer.from("LICENSE_VALIDATED").toString('base64');

// SETTING BOT
global.owner = '6281249703469'
global.versi = version
global.namaOwner = "alip clutcH"
global.packname = 'alip gege geming'
global.botname = 'alip ai MD'
global.botname2 = 'alip ai MD'

global.tempatDB = 'database.json' // Jangan ubah
global.botSecretKey = "alip-ai" // Jangan ubah

global.custompairing = "ALIPGGWP"; /* custom pairing lu */

global.ramsapikey = 'your_rams_api_key_here' // Ganti dengan API key mu

// Harga Buy Prem & Sewa Bot 
global.harga = {
    prem: "5000",
    sewa: "10000"
}

// harga sewa 
global.sewa = {
    bulan1: 10000,
    bulan3: 25000, 
    bulan6: 45000,
    bulan12: 80000
}

// limit harian bot
global.limitHarian = 10; // Ganti sesuai keinginan

// SUBDO CF
global.cloudflareZoneId = 'zode token'
global.cloudflareApiToken = 'token cf'
global.cloudflareDomain = 'domain.com'

// ======== APIKEY ALIP AI GAUSAH DI UBAH !!! ==============
global.apialip = "https://docs-alip.clutch.web.id"
global.btc = "https://api.botcahx.eu.org"
global.apikeyalip = "alipaiapikeybaru"
global.yudzxml = "https://api.yydz.biz.id"
global.apikeyyud = "alipaixyudz"
global.termai = "https://api.termai.cc"
global.apitermai = "alipaitermai2026"
global.fgsi = "https://fgsi.dpdns.org"
global.fgsiApikey = "RahmadXElaina"
global.apiPitu = "https://api.pitucode.com"
global.PituKey = "alipaipitu2026"

// ========PANEL SETTING !!!===============
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://" // Domain lu
global.apikey = "-" //ptla
global.capikey = "-" //ptlc
// ========================================

// Settings Link / Tautan
global.linkOwner = "https://wa.me/6281249703469"
global.linkGrup = "https://chat.whatsapp.com/BqJAqcdEjijJHrIWHNr1la"

// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 3000
global.delayPushkontak = 6000

// Settings Channel / Saluran
global.linkSaluran = "https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18"
global.idSaluran = "120363423239131660@newsletter"
global.namaSaluran = "# channel alip ai"


// Settings All Payment
global.dana = "081249703469" // ubah jadi nomor dana kalian 
global.gopay = " blm tersedia " // ubah jadi nomor gopay kalian


// Settings Image Url
global.image = {
// gambar menu awal
menu: "https://img2.pixhost.to/images/7890/726208281_alip-1778751576660.jpg",
// menu v3
menuv3: "https://img2.pixhost.to/images/7890/726215059_alip-1778752430422.jpg",
//banner welcome 
welcome: "https://img2.pixhost.to/images/6406/704218036_media.jpg", 
//banner left 
left: "https://img2.pixhost.to/images/6406/704218036_media.jpg", 
// logo saat bot reply pesan
reply: "https://img2.pixhost.to/images/7890/726214915_alip-1778752411169.jpg", 
canvas: "https://img1.pixhost.to/images/9319/649726402_media.jpg", 
// ubah jadi qris kalian
qris: "https://img1.pixhost.to/images/9307/649554404_media.png"
}

// Message Command 
global.mess = {
    limit: `🎀 *Limit habis*\nSilakan ketik *.claim* untuk klaim bonus limit\nAtau *.buyprem* untuk upgrade ke Premium.`,
    owner: `🎀 *Akses ditolak*\nFitur ini hanya tersedia untuk *Owner Bot*.`,
    verifikasi: `🎀 *Akses ditolak*\nSilakan ketik *.daftar nama,umur* untuk mengakses seluruh fitur bot.`,
    admin: `🎀 *Akses ditolak*\nFitur ini khusus untuk *Admin Grup*.`,
    botAdmin: `🎀 *Akses ditolak*\nBot harus menjadi *Admin Grup* untuk menjalankan fitur ini.`,
    group: `🎀 *Akses ditolak*\nFitur ini hanya dapat digunakan di dalam *Grup*.`,
    private: `🎀 *Akses ditolak*\nFitur ini hanya dapat digunakan di *Chat Pribadi*.`,
    prem: `🎀 *Akses ditolak*\nFitur ini hanya tersedia untuk *User Premium*.\nKetik *.prem* untuk informasi upgrade.`,
    wait: `🎀 *Mohon tunggu...*\nPermintaan sedang diproses.`,
    error: `🎀 *Terjadi kesalahan*\nSilakan coba kembali beberapa saat lagi.`,
    done: `🎀 *Berhasil*\nProses telah diselesaikan.`
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})
