/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 *
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 */

const axios = require('axios')
const { ImageUploadService } = require('node-upload-images')

async function uploadPixhost(buffer, filename = "file.jpg") {
    try {
        const service = new ImageUploadService('pixhost.to');
        const { directLink } = await service.uploadFromBinary(buffer, filename);
        return directLink;
    } catch (e) {
        console.error('Pixhost Upload Error:', e.message);
        return null;
    }
}

let handler = async (m, { alip, text, command, isCreator, isPremium, Reply, example }) => {
    if (!isCreator && !isPremium) return Reply(global.mess.prem)
    
    if (!text) return Reply(`📌 *Contoh penggunaan:*\n.${command} Nama Channel|Jumlah Followers|Deskripsi\n\n*Contoh:*\n.${command} alip|9800|Channel keren`)

    const args = text.split('|')
    if (args.length < 3) return Reply('❌ Format salah! Gunakan: name|followers|desc')
    
    const [name, followers, desc] = args.map(v => v.trim())
    
    if (isNaN(followers)) return Reply('❌ Jumlah followers harus angka!')

    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''

    if (!/image/.test(mime)) return Reply('❌ Reply gambar yang mau dijadikan fake channel!')

    await alip.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

    try {
        const media = await q.download()
        if (!media) throw new Error('Gagal download gambar')

        const imageUrl = await uploadPixhost(media, 'image.jpg')
        if (!imageUrl) throw new Error('Gagal upload gambar ke server')

        const now = new Date()
        const day = String(now.getDate()).padStart(2, '0')
        const month = String(now.getMonth() + 1).padStart(2, '0')
        const year = now.getFullYear()
        const tanggal = `${day}/${month}/${year}`

        const apiUrl = `https://api.zenzxz.my.id/maker/fakechannel?url=${encodeURIComponent(imageUrl)}&name=${encodeURIComponent(name)}&followers=${encodeURIComponent(followers)}&desc=${encodeURIComponent(desc)}&date=${encodeURIComponent(tanggal)}`
        
        const response = await axios.get(apiUrl, { 
            responseType: 'arraybuffer',
            timeout: 60000
        })

        await alip.sendMessage(m.chat, {
            image: Buffer.from(response.data),
            caption: `✅ *Fake Channel Generated*\n\n📌 *Name:* ${name}\n👥 *Followers:* ${followers}\n📅 *Date:* ${tanggal}\n📝 *Description:* ${desc}`
        }, { quoted: m })

        await alip.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

    } catch (error) {
        console.error('[FAKECHANNEL ERROR]', error)
        await alip.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
        
        if (error.response?.status === 404) {
            Reply('❌ API tidak ditemukan!')
        } else if (error.code === 'ECONNABORTED') {
            Reply('⏱️ Timeout, coba lagi nanti!')
        } else {
            Reply(`❌ Gagal: ${error.message}`)
        }
    }
}

handler.command = ['fakechannel', 'fakech', 'fkchannel']
handler.help = ['fakechannel <name|followers|desc> (reply gambar)']
handler.tags = ['maker']
handler.premium = true

module.exports = handler