let handler = async (m, { alip, command, args, isCreator, isPremium, Reply, text }) => {
    if (!m.isGroup) return Reply('❌ Perintah ini hanya untuk grup!')
    
    if (!text) {
        return Reply(`Gunakan dengan cara .fitnah *@tag|pesantarget|pesanbot*\n\n_Contoh_\n\n.fitnah @${m.sender.split("@")[0]}|enak ga semalem|enak banget`)
    }

    let parts = text.split("|")
    let org = parts[0]
    let target = parts[1]
    let bot = parts[2]

    if (!org || !org.startsWith('@')) {
        return Reply('Tag orangnya! Contoh: @user')
    }
    
    if (!target) {
        return Reply('Masukkan pesan target!')
    }
    
    if (!bot) {
        return Reply('Masukkan pesan bot!')
    }

    let orgId = org.replace('@', '')
    let orgJid = orgId + '@s.whatsapp.net'
    
    if (m.metadata?.participants) {
        let participant = m.metadata.participants.find(p => 
            p.jid === orgJid || 
            p.id === orgId + '@lid' ||
            (p.lid && p.lid === orgId + '@lid')
        )
        if (participant) {
            orgJid = participant.jid || participant.id?.replace('@lid', '@s.whatsapp.net')
        }
    }
    
    let mentions = []
    let mentionMatch = target.match(/@(\d+)/g)
    if (mentionMatch) {
        mentions = mentionMatch.map(v => {
            let num = v.replace('@', '')
            let jid = num + '@s.whatsapp.net'
            if (m.metadata?.participants) {
                let p = m.metadata.participants.find(x => 
                    x.jid === jid || 
                    x.id === num + '@lid' ||
                    (x.lid && x.lid === num + '@lid')
                )
                if (p) return p.jid
            }
            return jid
        }).filter(Boolean)
    }

    let msg1 = {
        key: {
            fromMe: false,
            participant: orgJid,
            remoteJid: m.chat
        },
        message: {
            extendedTextMessage: {
                text: target,
                contextInfo: {
                    mentionedJid: mentions
                }
            }
        }
    }

    let msg2 = {
        key: {
            fromMe: false,
            participant: orgJid,
            remoteJid: m.chat
        },
        message: {
            conversation: target
        }
    }

    await alip.sendMessage(m.chat, {
        text: bot,
        mentions: mentions
    }, {
        quoted: mentions.length > 0 ? msg1 : msg2
    })
}

handler.command = ["fitnah"]

module.exports = handler