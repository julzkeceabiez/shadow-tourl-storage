## Rules & Guidelines
1. Dilarang keras membagikan script secara cuma cuma.
2. Penjualan ( reseller only ) upgrade reseller ke **6381249703469**
5. Jangan menghapus credit yang ada di script.  
6. Permintaan fitur untuk update diperbolehkan, selama masuk akal.  
7. Bot akan selalu diperbarui dan dikembangkan secara berkala.

# RENAME SCRIP CUKUP BAGIAN ( SETTING.JS ) DILARANG KERAS BYPASS DB BOT/ATAU MENCOPOT SISTEM DB!!!

## Cara Menjalankan Script
1. Upload file ke panel hosting.  
2. Ekstrak (unarchive) file script.  
3. Pilih Node.js versi 23 atau lebih tinggi.  
4. Masukkan password pairing yang telah diberikan.  
5. Masukkan nomor bot.

## Cara pasang backup bot supaya database lama tidak hilang 
1. Upload sc versi terbaru, lalu unarchive
2. Upload file backup kalian, lalu unarchive
3. Restart.

© 2024-2025 @alifalfrl__

## New update v12.0.0

`new fitur`
___________
1. .web2apk
2. .wanted 
3. .musikcard
4. .autocorrect on/off
5. .cekff
6. 
│▣ .addrespon
│▣ .delrespon
│▣ .listrespon

7. trial prem

`fix fitur`
___________
1. .toimg
2. .tovideo
3. .togif
4. .removebg
5. autoai
6. ai ( supp image, video, audio )
7. ai mention
8. cpanel menu
9. .soraai
10. .veo3
11. .fekml dm ganda
12. list sistem fix spasi icon prefix
13. .caristiker
14. auto downloader
15. perubahan struktur reply image
16. .emoji
17. .nulis
18. .cekdana
19. .telanjang
20. .SoundCloud
21. .audiosurah
22. .stalkroblox
23. .tiktokstalk

ydhlah segini aja dlu, next apdet baru fix fix lagi 😞

btw up reseller, pt, own bisa ke wa.me//6281249703469

`remove fitur`
___________

 * ©alipai Since 2024 - 2026
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
